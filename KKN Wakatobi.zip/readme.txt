Thanks for downloading this theme!

Theme Name: Maundy
Theme URL: https://bootstrapmade.com/maundy-free-coming-soon-bootstrap-theme/
Author: BootstrapMade.com
Author URL: https://bootstrapmade.com